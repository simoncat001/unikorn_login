import { useState, useEffect, useCallback } from "react";
import { Box, Typography, Button, TextField, IconButton } from "@material-ui/core";
import EditIcon from "@material-ui/icons/Edit";
import CheckIcon from "@material-ui/icons/Check";
import CloseIcon from "@material-ui/icons/Close";

import { useHistory } from "react-router-dom";
import Common from "../common/Common";
import Map from "../common/Map";
import ReviewStatusUtils from "../common/ReviewStatusUtils";
import { useStyles, BreadNav, DetailDivier } from "./DetailUtils";
import {
  ERROR_PATH,
  DEVELOPMENT_DATA_EDIT_PATH,
  DEVELOPMENT_DATA_PATH,
  DEVELOPMENT_DATA_DETAIL_PATH,
} from "../common/Path";
import { CenterSnackbar } from "../common/Utils";
import DevelopmentDataService, {
  DevelopmentData,
  DevelopmentDataJSON,
} from "../api/DevelopmentDataService";
import Icon from "./Icon";
import LoadingComponent from "./LoadingComponent";
import EditButton from "./detail/EditButton";
import RejectedReason from "./detail/RejectedReason";
import DetailDataItem from "./detail/DetailDataItem";
import PreviewCard from "./detail/PreviewCard";
import ContentObject from "./DevelopmentDataContent";
import { REVIEW_STATUS_PASSED_REVIEW_WAITING_PUBLISHED } from "../common/ReviewStatusUtils";

const PublishedButton: React.FC<{
  review_status: string;
  id: string;
  setDevJsonData: React.Dispatch<
    React.SetStateAction<DevelopmentDataJSON | undefined>
  >;
  setStatus: React.Dispatch<React.SetStateAction<number>>;
  setAlertOpen: React.Dispatch<React.SetStateAction<boolean>>;
}> = ({ review_status, id, setDevJsonData, setStatus, setAlertOpen }) => {
  const btnClasses = Common.buttonStyles();
  const handleClick = async () => {
    try {
      const status = await DevelopmentDataService.applyPublished(id);
      setStatus(status);
      if (status === 0) {
        const devDataObject: DevelopmentData =
          await DevelopmentDataService.getDevData(id);
        setDevJsonData(devDataObject.json_data);
      }
      setAlertOpen(true);
    } catch (e) {
      console.error(e);
    }
  };
  if (review_status === REVIEW_STATUS_PASSED_REVIEW_WAITING_PUBLISHED)
    return (
      <Button
        className={btnClasses.SecondarySmallIcon}
        startIcon={Icon.editIcon}
        disableRipple
        onClick={handleClick}
      >
        数据发表
      </Button>
    );
  else return null;
};

const DevDataDetailComponent: React.FC<{ id: string; publicPage: boolean }> = ({
  id,
  publicPage,
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [devJsonData, setDevJsonData] =
    useState<DevelopmentDataJSON | undefined>(undefined);
  const [alertOpen, setAlertOpen] = useState(false);
  const [status, setStatus] = useState(0);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editedTitle, setEditedTitle] = useState("");
  const classes = useStyles();
  const fontClasses = Common.fontStyles();
  const history = useHistory();

  // 加载数据的函数，使用 useCallback 避免无限循环
  const loadData = useCallback(async () => {
    setIsLoaded(false);
    try {
      const devDataObject: DevelopmentData =
        await DevelopmentDataService.getDevData(id);
      setDevJsonData(devDataObject.json_data);
    } catch (e) {
      setDevJsonData(undefined);
    }
    setIsLoaded(true);
  }, [id]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  // 监听 location state 的变化，如果有 refresh 标记则重新加载
  useEffect(() => {
    const locationState = history.location.state as any;
    if (locationState?.refresh) {
      void loadData();
      // 清除 state 中的 refresh 标记，避免重复刷新
      history.replace(history.location.pathname, {});
    }
  }, [history, loadData]); if (!isLoaded) {
    return <LoadingComponent />;
  }
  if (!devJsonData) {
    history.replace(ERROR_PATH);
    return null;
  }

  // 优先使用 title 字段，如果没有则使用 data_content 中的"实验名称"字段
  const experimentNameField = devJsonData.data_content?.find(
    item => item.title === "实验名称" || item.title === "名称"
  );
  const DetailTitle = devJsonData.title || (experimentNameField?.content as string) || "未命名";

  // 开始编辑标题
  const handleStartEdit = () => {
    setEditedTitle(devJsonData.title);
    setIsEditingTitle(true);
  };

  // 取消编辑
  const handleCancelEdit = () => {
    setIsEditingTitle(false);
    setEditedTitle("");
  };

  // 保存标题
  const handleSaveTitle = async () => {
    try {
      const result = await DevelopmentDataService.updateDataContent(
        id,
        devJsonData.data_content,
        editedTitle
      );
      setStatus(result ?? 0);
      setAlertOpen(true);
      if (result === 0) {
        // 更新成功，重新加载数据
        await loadData();
        setIsEditingTitle(false);
      }
    } catch (e) {
      setStatus(-1);
      setAlertOpen(true);
      console.error(e);
    }
  };

  return (
    <Box display="flex" flexDirection="column" m={4}>
      <CenterSnackbar
        open={alertOpen}
        status={status}
        handleClose={() => {
          setAlertOpen(false);
        }}
        ifPublished={true}
      />
      {!publicPage ? (
        <BreadNav
          HOME_PATH={DEVELOPMENT_DATA_PATH}
          breadName={DetailTitle}
          DETAIL_PATH={DEVELOPMENT_DATA_DETAIL_PATH + "/" + id}
        />
      ) : (
        <div />
      )}

      <Box display="flex" my={3}>
        {!isEditingTitle ? (
          <Box display="flex" alignItems="center">
            <Typography className={fontClasses.DetailTitle}>
              {DetailTitle}
            </Typography>
            <IconButton
              size="small"
              onClick={handleStartEdit}
              style={{ marginLeft: 8 }}
            >
              <EditIcon fontSize="small" />
            </IconButton>
          </Box>
        ) : (
          <Box display="flex" alignItems="center">
            <TextField
              value={editedTitle}
              onChange={(e) => setEditedTitle(e.target.value)}
              variant="outlined"
              size="small"
              style={{ marginRight: 8 }}
              autoFocus
            />
            <IconButton
              size="small"
              onClick={handleSaveTitle}
              color="primary"
            >
              <CheckIcon />
            </IconButton>
            <IconButton
              size="small"
              onClick={handleCancelEdit}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        )}
      </Box>
      {!publicPage ? (
        <Box display="flex" justifyContent="flex-end">
          <Box>
            <PublishedButton
              review_status={devJsonData.review_status}
              id={id}
              setDevJsonData={setDevJsonData}
              setAlertOpen={setAlertOpen}
              setStatus={setStatus}
            />
          </Box>
        </Box>
      ) : null}

      <Box display="flex" className={classes.detailBackground}>
        <Box display="flex" flexDirection="row" mx={2} my={3}>
          <Box display="flex" flexDirection="column">
            <DetailDataItem
              label={Map.developmentDataItemMap.author}
              content={devJsonData.author}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.create_timestamp}
              content={devJsonData.create_timestamp}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.reviewer}
              content={devJsonData.reviewer}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.review_status}
              content={
                ReviewStatusUtils.isDraft(devJsonData.review_status)
                  ? ""
                  : ReviewStatusUtils.reviewStatusMap[devJsonData.review_status]
              }
              icon={
                <RejectedReason
                  review_status={devJsonData.review_status}
                  rejected_reason={devJsonData.rejected_reason}
                />
              }
            />
          </Box>
          <DetailDivier />
          <Box
            display="flex"
            flexDirection="column"
            ml={3}
            style={{ width: "auto" }}
          >
            <DetailDataItem
              label={Map.developmentDataItemMap.template_name}
              content={devJsonData.template_name}
              isLeft={false}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.data_generate_method}
              content={
                Map.dataGenerateMethodMap[devJsonData.data_generate_method]
              }
              isLeft={false}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.institution}
              content={devJsonData.institution}
              isLeft={false}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.template_type}
              content={Map.templateTypeMap[devJsonData.template_type]}
              isLeft={false}
            />
            <DetailDataItem
              label={Map.developmentDataItemMap.MGID}
              content={devJsonData.MGID}
              isLeft={false}
            />
          </Box>
        </Box>
      </Box>
      <PreviewCard
        itemType={"data"}
        content={
          <ContentObject
            content={devJsonData.data_content}
            order={devJsonData.word_order}
          />
        }
        showEditButton={!publicPage}
        onEditClick={() => {
          history.push(`${DEVELOPMENT_DATA_EDIT_PATH}/${id}?hideFiles=true`);
        }}
      />
      {!publicPage ? (
        <Box display="flex" justifyContent="flex-end" mt={2}>
          <EditButton
            review_status={devJsonData.review_status}
            EDIT_PATH={DEVELOPMENT_DATA_EDIT_PATH + "/" + id}
            type={"data"}
          />
        </Box>
      ) : null}
    </Box>
  );
};

export default DevDataDetailComponent;
